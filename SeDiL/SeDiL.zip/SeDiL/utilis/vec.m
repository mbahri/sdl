function v = vec(A)
v = A(:);