cd SLEP_package_4.1;
run mexC
cd ../imageUtility
mex interp2.cpp